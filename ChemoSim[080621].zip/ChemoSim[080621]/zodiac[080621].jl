module ChemoSim
"""
A Julia code to simulate and solve various chemostat models in Matrix Vector
Form

Authors:
 - Alexandra Mazanko (University of Guelph)
 - Courtney Allen (University of Guelph)
"""

#####################################################
# Last Update: August 6th, 2021
# Global Sensitivity was broken seeing that was why Global Module didnt work :)
#####################################################
# We include the necessary the packages to motivate all
# the functions to process properly
using LinearAlgebra
using DifferentialEquations
using Plots
using SparseArrays
using DiffEqSensitivity
using QuasiMonteCarlo
using DelimitedFiles
using ..Rho
#####################################################


function InitialConditions()
   #####################################################
   # We create a function that reads a text file with stated initial conditions
   # of the given ODE problem and returns a vector to be used.
   # on input:
   #     u0text: text file that contains initial conditions labelled "u0text"
   # ---------------------------------------------------
   # returns:
   #     u0: initial conditions for system as a vector
   #####################################################
   u0in = readdlm("u0text.txt",Float64)
   #u0 = [
   #0.5; 0.5; 0.5; 0.5; 0.5; 0.5; 0.5; 0.5
   #]

   u0 = u0in[:]

   return u0

end



function transportmatrix_definition()
   #####################################################
   # We create a function that reads a text file with information regarding the
   # transport matrix of the given ODE problem and returns a vector to be used.
   # on input:
   #     transportmatrix_text: text file that contains, in order,
   #                           x coordinates, y coordinates and values of
   #                           transport matrix labelled "transportmatrix_text"
   # ---------------------------------------------------
   # returns:
   #     TM: sparse matrix array that contains values in their corresponding positions
   #####################################################
   Tinfo = readdlm("transportmatrix_text.txt",',',Float64)

   T1 = Tinfo[1,:]
   T2 = Tinfo[2,:]
   TMT = Tinfo[3,:]

   TM = sparse(T1,T2,TMT)
   return TM
   end

function petersenmatrixtranspose_definition()
   #####################################################
   # We create a function that reads a text file with information regarding the
   # transport matrix of the given ODE problem and returns a vector to be used.
   # on input:
   #     petersenmatrix_text: text file that contains, in order,
   #                           x coordinates, y coordinates and values of
   #                           Petersen matrix labelled "petersenmatrix_text"
   # ---------------------------------------------------
   # returns:
   #     PM: sparse matrix array that contains values in their corresponding positions
   #####################################################
      Pinfo = readdlm("petersenmatrix_text.txt",',',Float64)

      P1 = Pinfo[1,:]
      P2 = Pinfo[2,:]
      Q = Pinfo[3,:]

      PM = sparse(P2,P1,Q)
      return PM
   end

function inflowvector_definition()
   #####################################################
   # this is where the input of the inflow vector takes place
   # this follows a simple array type
   # on input:
   #     IV: text file that contains inflow vector information
   #         labelled "inflow_text"
   # ---------------------------------------------------
   # returns:
   #    IV: single column array containing the inflow vector
   #####################################################

   IV = readdlm("inflow_text.txt",',',Float64)
   #IV=[0.0; 0.0 ; 0.0; 0.0; 20.0; 0.0; 0.0; 0.0]
   return IV
   end


function length_definition()
   #####################################################
   # Function is meant to be called as a method to define the sizes of
   # parameter arrays without having to call the function again.
   # ---------------------------------------------------
   # returns:
   #    lvc: value that contains that the total length of the combined
   #           reaction parameter and inflow vectors
   #####################################################

   lvc = [length(Main.Rho.reactionparameter_definition()),length(inflowvector_definition())]

   return lvc
end




function RHSfun(du,u,p,t)
   ######################################################
   # defines right hand side for chemostat models:
   # ----------------------------------------------------
   # note:  normally the frst argument should be
   #        du, but this seems to not work here, but if
   #        it is omitted, it runs
   # ----------------------------------------------------
   # on input:
   #   u:  state variable
   #   p:  array of arrays containg all model parameters
   #       p[1]: transport matrix
   #       p[2]: transpose of Petersen matrix
   #       p[3]: inflow vector
   #       p[4]: vector of reaction parameters
   #   t:  time (not used when system is autonomous)
   # returns:
   #   du:  rate of change for state variable
   ######################################################
   # N.B.:  i determine the number of process here from
   #    the size of the petersen matrix as size(p[2])[2].
   #    explicitly handing the number of processes over
   #    to the function reactionrates made programming it
   #    much easier
   ######################################################
      lvc = length_definition()

      RP = p[1:lvc[1]]
      IV = p[lvc[1]+1:lvc[1]+lvc[2]]

      TM = transportmatrix_definition()

      PM = petersenmatrixtranspose_definition()

      #TM = sparse(1:8,1:8,parm[1])

      #P1 = [1,5,2,6,3,7,4,8,1,1,2,1,2,3,1,2,4]
      #P2 = [1,1,2,2,3,3,4,4,5,6,6,7,7,7,8,8,8]
      #PM = sparse(P2,P1,parm[2])

      rr = Main.Rho.reactionrates(RP,u,size(PM)[2])

      du .= TM*u + Matrix(PM)*rr + IV

end

function ExampleSol(tspan::Tuple,u0::Vector)
   ######################################################
   # Computes an approximated solution to the given ODE problem
   # provided in RHS fun
   # ----------------------------------------------------
   # on input:
   #   tspan: time interval that the solution will be solved over
   #
   #      u0: initial conditions for the given problem
   # returns:
   #   sol:  array that contains solutions
   ######################################################



   RP = Main.Rho.reactionparameter_definition() #length 12
   IV = inflowvector_definition() #length 8

   SCALE = [RP;IV]

   parm = zeros(length(SCALE))
   parm[1:length(RP)] = RP
   parm[length(RP) + 1 : length(RP) + length(IV)] = IV


   prob = ODEProblem(RHSfun,u0,tspan,parm)

   alg = Rosenbrock23()
   sol = solve(prob,alg)

   return sol

end


end
