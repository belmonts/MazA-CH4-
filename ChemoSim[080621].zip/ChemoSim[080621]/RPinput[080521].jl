module Rho


function reactionparameter_definition()
   #####################################################
   # these are the reaction parameters that are necessary for
   # the funtion reactionrates.
   # ---------------------------------------------------
   # N.B it is worth nothing that the position of the reaction
   # parameter in the array below corresponds to it's position in
   # the formulation of reactionrates()
   # ---------------------------------------------------
   # on input:
   # MANUAL: user inputs the necessary reaction parameters needed
   #         needed for reaction rates
   # ---------------------------------------------------
   # returns:
   #   rpvc: vector containing the reaction parameters
   #####################################################
 rpvc = [3, 0.5, 0.5, 0.1, 1, 0.75, 0.15, 10, 1.998, 10e-6, 5, 0.02]
 return rpvc
 end




 function reactionrates(rpvc,sx,NREAC)
 #####################################################
 # these are the reaction rates for competition in
 # the chemostat with lysis terms using Monod
 # kinetics for growth
 # ---------------------------------------------------
 # on input:
 #   NREAC:  number of processes
 #   sx:     state variable
 #   rpvc:   vector containing reaction parameters
 # ---------------------------------------------------
 # returns:
 #   rrates: vector of reaction rates
 #####################################################
    rrates=Array{Real}(undef,NREAC)
    rrates[1]= (rpvc[1]*sx[5]/(rpvc[2] + sx[5]))*sx[1]
    rrates[2]= (rpvc[3]*sx[6]/(rpvc[4] + sx[6] + rpvc[5]*sx[8]))*sx[2]
    rrates[3]= (rpvc[6]*sx[7]/(rpvc[7] + sx[7] + (sx[7]^2)/rpvc[8]))*sx[3]
    rrates[4]= (rpvc[9]*sx[8]/(rpvc[10] + sx[8] + rpvc[11]*sx[7]))*sx[4]
    rrates[5]= (rpvc[12]*sx[1])
    rrates[6]= (rpvc[12]*sx[2])
    rrates[7]= (rpvc[12]*sx[3])
    rrates[8]= (rpvc[12]*sx[4])
    return rrates
 end




end
