module GlobeSense

"""
A Julia module to perform Global Sensitivity Analysis on given ODE Problem

Authors:
 - Alexandra Mazanko (University of Guelph)
 - Courtney Allen (University of Guelph)
"""

#####################################################
# Last Update: August 6tg, 2021
# FIXED ALL THE BROKEN THINGS
#####################################################
# We include the necessary the packages to motivate all
# the functions to process properly
using LinearAlgebra
using DifferentialEquations
using Plots
using SparseArrays
using DiffEqSensitivity
using QuasiMonteCarlo
using DelimitedFiles
using ..Rho
using ..ChemoSim
#####################################################

function GlobalSense_Variation()
   #####################################################
   #Function serves to define which variables the user is choosing to vary in
   #global sensitivity analysis
   # on input:
   #     user clarifies how reaction parameters will be varied.
   #     lower_bound: contains the lower bound of the given sensitivity analysis
   #     upper_bound: contains the upper bound of the given sensitivity analysis
   # ---------------------------------------------------
   # returns:
   #     GSV: array containing the lower and upper bounds of the given global
   #              global sensitivity analysis
   #####################################################
   lower_bound = [3, 0.5, 0.5, 0.1, 1, 0.75, 0.15, 10, 1.998, 10e-6, 5, 0.02]

   upper_bound = [3, 0.5, 0.5, 0.1, 1, 0.75, 0.15, 10, 1.998, 10e-6, 5, 0.02]*1.10

   GSV = [lower_bound,upper_bound]

   return GSV
end





function RHSfunDUO(du,u,p,t)
   ######################################################
   # defines right hand side for chemostat models for global
   # sensitivity analysis:
   # ----------------------------------------------------
   # note:  normally the frst argument should be
   #        du, but this seems to not work here, but if
   #        it is omitted, it runs
   # ----------------------------------------------------
   # on input:
   #   u:  state variable
   #   p:  array of arrays containg all model parameters
   #       p[1]: transport matrix
   #       p[2]: transpose of Petersen matrix
   #       p[3]: inflow vector
   #       p[4]: vector of reaction parameters
   #   t:  time (not used when system is autonomous)
   # returns:
   #   du:  rate of change for state variable
   ######################################################
   # N.B.:  i determine the number of process here from
   #    the size of the petersen matrix as size(p[2])[2].
   #    explicitly handing the number of processes over
   #    to the function reactionrates made programming it
   #    much easier
   ######################################################

   lvc = Main.ChemoSim.length_definition()

   parms = zeros(lvc[1]+lvc[2])
   parms[1:lvc[1]] = rpd
   parms[lvc[1] + 1 : lvc[1] + lvc[2]] = ivd

   parms[parmsToVary] = p

   RP = parms[1:lvc[1]]
   IV = parms[lvc[1]+1:lvc[1]+lvc[2]]

   TM = Main.ChemoSim.transportmatrix_definition()

   PM = Main.ChemoSim.petersenmatrixtranspose_definition()

   rr = Main.Rho.reactionrates(RP,u,size(PM)[2])

   du .= TM*u + Matrix(PM)*rr + IV
end

function GlobalSenseSol(tspan::Tuple,u0::Vector,num::Int64)
   #####################################################
   # Function serves to perform Global Sensitivity Analysis on given ODEProblem
   # that the user creates in RHSfun. Currently meant to only evaluate Reaction
   # parameters.
   # on input:
   #     tspan: timespan needed for assumed system of equations
   #        u0: initial conditions of given system
   #       num: number of simulations to run with varied parameters
   # ---------------------------------------------------
   # returns:
   #     sobol_result: approximated solution to given system of differental equations
   #####################################################

   u0 = Main.ChemoSim.InitialConditions()
   lvc = Main.ChemoSim.length_definition()
   RP = Main.Rho.reactionparameter_definition()
   GSV = GlobalSense_Variation()

   parm = zeros(lvc[1])
   parm[1:lvc[1]] = GSV[2] #[RP[1]*1.03, RP*1.12]

   global parmsToVary = 1:lvc[1]

   global rpd = Main.Rho.reactionparameter_definition()
   global ivd = Main.ChemoSim.inflowvector_definition()

   prob = ODEProblem(RHSfunDUO,u0,tspan,parm)
   t = collect(range(0, stop=10, length=100))
   alg = Rosenbrock23()

   f1 = function (p)
      prob1 = remake(prob;p=p)
      sol  = solve(prob1, alg; saveat=t)
      sol[end]#we make our designated region the final solution here.
   end

   N = num
   lb = parm
   ub = parmsToVary
   sampler = SobolSample()
   A,B = QuasiMonteCarlo.generate_design_matrices(N,lb,ub,sampler)

   sobol_result = GlobalSensitivity.gsa(f1,Sobol(), A,B)

   return sobol_result

end



end
